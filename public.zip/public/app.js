console.log("hello");

function greet()
{
	const input = document.getElementById("txtCountry")
	country= input.value;
//remove this for heroku http://localhost:3000/search?word=${country}
	const url =`/search?word=${country} `

	fetch(url).then((response)=>{
		return response.json()
	}).then((newdata)=>{
		if(newdata)
		{
		document.getElementById("txtSource").innerHTML=`<b>Source:</b> ${newdata.source}`
		  			  document.getElementById("txtAuthor").innerHTML=`<b>Author:</b>${newdata.author}`
		  				document.getElementById("txtTitle").innerHTML=`<b>Title:</b>${newdata.title}`
						document.getElementById("txtDescription").innerHTML=`<b>Description:</b>${newdata.description}`
						document.getElementById("txturl").innerHTML=`<b>Url: </b>${newdata.url}`
						document.getElementById("txturltoimg").innerHTML=`<b>Image-Url: <img src="${newdata.urlToImage}" style="height:300px; width:300px;" class="img-thumbnail" /></b>`
			console.log(newdata);
			
		}
		else
		{
				document.getElementById("txtError").innerHTML=newdata.error
		
		}
	}).catch((e)=>{
		console.log("error:",e);

	})
}