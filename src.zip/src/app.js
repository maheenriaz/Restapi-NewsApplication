const express = require('express')
const app = express();
const yargs= require('yargs');
const hbs= require('hbs');
const path = require('path')
const request= require('request');


app.set('view engine','hbs');

app.use(express.static(path.join(__dirname, '../public/')));

const viewFolder = path.join(__dirname,'../templates/views/')
app.set('views',viewFolder);

app.get('/',(req,res)=>{
	res.render('index')
})

app.get('*',(req,res)=>{
	res.send('no page found')
})

app.get('/search',(req,res)=>{
	const {word} = req.query
	const option =
	{
	url:`http://newsapi.org/v2/everything?q=${word}&apiKey=9fe4caf927e142149d5984543cbb6dd4`,
	json:true 

	}
	console.log(option);

	const NewsCallback =(error,response)=>
	{
		console.log("error:",error);
		console.log(" statuscode :" , response && response.statuscode);
		console.log(response.body);
		let len=5;
 			while(len > 1)
  			{ 
  				//console.log("hello");
				const values =  response.body.articles
	
  				const source = values[len].source.name;
				const author =  values[len].author
				const title = values[len].title
				const description =  values[len].description
				const url =  values[len].url
				const urlToImage =  values[len].urlToImage
 		
 					console.log(source,author,title);
					  	const data ={
						word,
						error,
						source,
						author,
						title ,
						description ,
						url,
						urlToImage
						      }	
			     
			    	return	 res.send(data)
			   		 len--;	
		
 			}

  		}	
	
	


request(option,NewsCallback)

 })

const port = process.env.PORT || 5000

app.listen(port,()=>{console.log(`running ${port}`);})